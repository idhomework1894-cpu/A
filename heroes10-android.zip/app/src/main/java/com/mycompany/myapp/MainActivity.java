package com.mycompany.myapp;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowInsets;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
 private WebView web;
 private static final String HOME = "https://android-app-apk.netlify.app/";
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  web = new WebView(this);
  setContentView(web);
  web.setOnApplyWindowInsetsListener((v, insets) -> {
   if (android.os.Build.VERSION.SDK_INT >= 30) {
    android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
    v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
   }
   return insets;
  });
  getWindow().setNavigationBarColor(Color.parseColor("#93cdb7"));
  web.getSettings().setJavaScriptEnabled(true);
  web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(false);
  web.getSettings().setAllowContentAccess(false);
  web.setWebViewClient(new WebViewClient() {
   @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
    Uri uri = request.getUrl();
    if ("https".equals(uri.getScheme()) && Uri.parse(HOME).getHost().equals(uri.getHost())) return false;
    if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme()) || "mailto".equals(uri.getScheme()) || "tel".equals(uri.getScheme())) {
     try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (android.content.ActivityNotFoundException ignored) { }
    }
    return true;
   }
   @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
    if (request.isForMainFrame() && !isFinishing()) new AlertDialog.Builder(MainActivity.this).setTitle("Unable to load website").setMessage("Check your internet connection and try again.").setPositiveButton("Retry", (d,w) -> web.loadUrl(HOME)).setNegativeButton("Close", null).show();
   }
  });
  if (state == null || web.restoreState(state) == null) web.loadUrl(HOME);
 }
 @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
 @Override protected void onSaveInstanceState(Bundle state) { web.saveState(state); super.onSaveInstanceState(state); }
 @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
}
